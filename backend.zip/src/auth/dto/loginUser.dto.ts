export class LoginUserDto {
    login: string;
    password?: string;
}